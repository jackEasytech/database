--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.17
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.os_log DROP CONSTRAINT pk_log;
ALTER TABLE ONLY public.os_typologie DROP CONSTRAINT os_typologie_pkey;
ALTER TABLE ONLY public.os_r_personnel DROP CONSTRAINT os_r_personnel_pkey;
ALTER TABLE ONLY public.os_description DROP CONSTRAINT os_description_pkey;
ALTER TABLE ONLY public.os_condition DROP CONSTRAINT os_condition_pkey;
ALTER TABLE ONLY public.os_champ_modifiable DROP CONSTRAINT os_champ_modifiable_pkey;
ALTER TABLE ONLY public.os_benalmfic DROP CONSTRAINT os_benalmfic_pkey;
ALTER TABLE ONLY public.os_loginlog DROP CONSTRAINT "Pk_loginlog";
ALTER TABLE ONLY public.funben2s DROP CONSTRAINT "Cle primaire funben2s";
ALTER TABLE public.os_typologie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.os_r_personnel ALTER COLUMN id_pers DROP DEFAULT;
ALTER TABLE public.os_loginlog ALTER COLUMN id_loginlog DROP DEFAULT;
ALTER TABLE public.os_log ALTER COLUMN id_log DROP DEFAULT;
ALTER TABLE public.os_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.os_condition ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.os_champ_modifiable ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.os_benalmfic ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.funben2s ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.os_typologie_id_seq;
DROP TABLE public.os_typologie;
DROP SEQUENCE public.os_r_personnel_id_pers_seq;
DROP TABLE public.os_r_personnel;
DROP SEQUENCE public.os_loginlog_id_loginlog_seq;
DROP TABLE public.os_loginlog;
DROP SEQUENCE public.os_log_id_log_seq;
DROP TABLE public.os_log;
DROP SEQUENCE public.os_description_id_seq;
DROP TABLE public.os_description;
DROP SEQUENCE public.os_condition_id_seq;
DROP TABLE public.os_condition;
DROP SEQUENCE public.os_champ_modifiable_id_seq;
DROP TABLE public.os_champ_modifiable;
DROP SEQUENCE public.os_benalmfic_id_seq;
DROP TABLE public.os_benalmfic;
DROP SEQUENCE public.funben2s_id_seq;
DROP TABLE public.funben2s;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: funben2s; Type: TABLE; Schema: public; Owner: rami
--

CREATE TABLE funben2s (
    id bigint NOT NULL,
    fbdnai double precision,
    fbrnai double precision,
    fbncon character varying(100),
    fbnins character varying(100),
    fbfic character varying(100)
);


ALTER TABLE funben2s OWNER TO rami;

--
-- Name: funben2s_id_seq; Type: SEQUENCE; Schema: public; Owner: rami
--

CREATE SEQUENCE funben2s_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE funben2s_id_seq OWNER TO rami;

--
-- Name: funben2s_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rami
--

ALTER SEQUENCE funben2s_id_seq OWNED BY funben2s.id;


--
-- Name: os_benalmfic; Type: TABLE; Schema: public; Owner: rami
--

CREATE TABLE os_benalmfic (
    cprint double precision,
    cptypp double precision,
    cpncon double precision,
    cpddef double precision,
    id bigint NOT NULL,
    cpdrad double precision,
    cpdsai double precision,
    cphmaj double precision,
    cpimaj character varying(100),
    cpnmut character varying(100),
    cpncol character varying(100)
);


ALTER TABLE os_benalmfic OWNER TO rami;

--
-- Name: os_benalmfic_id_seq; Type: SEQUENCE; Schema: public; Owner: rami
--

CREATE SEQUENCE os_benalmfic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_benalmfic_id_seq OWNER TO rami;

--
-- Name: os_benalmfic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rami
--

ALTER SEQUENCE os_benalmfic_id_seq OWNED BY os_benalmfic.id;


--
-- Name: os_champ_modifiable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE os_champ_modifiable (
    id bigint NOT NULL,
    id_desc bigint,
    field character varying(100),
    type_field character varying(100)
);


ALTER TABLE os_champ_modifiable OWNER TO postgres;

--
-- Name: os_champ_modifiable_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE os_champ_modifiable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_champ_modifiable_id_seq OWNER TO postgres;

--
-- Name: os_champ_modifiable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE os_champ_modifiable_id_seq OWNED BY os_champ_modifiable.id;


--
-- Name: os_condition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE os_condition (
    id bigint NOT NULL,
    id_desc bigint,
    field character varying(50),
    operateur character varying(20),
    type_field character varying(20)
);


ALTER TABLE os_condition OWNER TO postgres;

--
-- Name: os_condition_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE os_condition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_condition_id_seq OWNER TO postgres;

--
-- Name: os_condition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE os_condition_id_seq OWNED BY os_condition.id;


--
-- Name: os_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE os_description (
    id bigint NOT NULL,
    libelle character varying(300),
    sql character varying(900),
    id_typologie bigint,
    colone_conditionupdate character varying(300),
    email character varying(100)
);


ALTER TABLE os_description OWNER TO postgres;

--
-- Name: os_description_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE os_description_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_description_id_seq OWNER TO postgres;

--
-- Name: os_description_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE os_description_id_seq OWNED BY os_description.id;


--
-- Name: os_log; Type: TABLE; Schema: public; Owner: rami
--

CREATE TABLE os_log (
    id_log bigint NOT NULL,
    date_log character varying(100),
    requete character varying(300),
    user_log character varying(200),
    avant_update text
);


ALTER TABLE os_log OWNER TO rami;

--
-- Name: os_log_id_log_seq; Type: SEQUENCE; Schema: public; Owner: rami
--

CREATE SEQUENCE os_log_id_log_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_log_id_log_seq OWNER TO rami;

--
-- Name: os_log_id_log_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rami
--

ALTER SEQUENCE os_log_id_log_seq OWNED BY os_log.id_log;


--
-- Name: os_loginlog; Type: TABLE; Schema: public; Owner: rami
--

CREATE TABLE os_loginlog (
    id_loginlog bigint NOT NULL,
    action character varying(50),
    source character varying(150),
    adresse_ip character varying(100),
    emplacement character varying(100),
    date_heure character varying(100),
    nom_user character varying(200),
    adresse_ip_public character varying(100)
);


ALTER TABLE os_loginlog OWNER TO rami;

--
-- Name: os_loginlog_id_loginlog_seq; Type: SEQUENCE; Schema: public; Owner: rami
--

CREATE SEQUENCE os_loginlog_id_loginlog_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_loginlog_id_loginlog_seq OWNER TO rami;

--
-- Name: os_loginlog_id_loginlog_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rami
--

ALTER SEQUENCE os_loginlog_id_loginlog_seq OWNED BY os_loginlog.id_loginlog;


--
-- Name: os_r_personnel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE os_r_personnel (
    id_pers bigint NOT NULL,
    identifiant character varying(30),
    mdp character varying(200),
    nom character varying(100),
    prenom character varying(50),
    email character varying(100)
);


ALTER TABLE os_r_personnel OWNER TO postgres;

--
-- Name: os_r_personnel_id_pers_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE os_r_personnel_id_pers_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_r_personnel_id_pers_seq OWNER TO postgres;

--
-- Name: os_r_personnel_id_pers_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE os_r_personnel_id_pers_seq OWNED BY os_r_personnel.id_pers;


--
-- Name: os_typologie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE os_typologie (
    id bigint NOT NULL,
    libelle character varying(60),
    icone character varying(25)
);


ALTER TABLE os_typologie OWNER TO postgres;

--
-- Name: os_typologie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE os_typologie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE os_typologie_id_seq OWNER TO postgres;

--
-- Name: os_typologie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE os_typologie_id_seq OWNED BY os_typologie.id;


--
-- Name: funben2s id; Type: DEFAULT; Schema: public; Owner: rami
--

ALTER TABLE ONLY funben2s ALTER COLUMN id SET DEFAULT nextval('funben2s_id_seq'::regclass);


--
-- Name: os_benalmfic id; Type: DEFAULT; Schema: public; Owner: rami
--

ALTER TABLE ONLY os_benalmfic ALTER COLUMN id SET DEFAULT nextval('os_benalmfic_id_seq'::regclass);


--
-- Name: os_champ_modifiable id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_champ_modifiable ALTER COLUMN id SET DEFAULT nextval('os_champ_modifiable_id_seq'::regclass);


--
-- Name: os_condition id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_condition ALTER COLUMN id SET DEFAULT nextval('os_condition_id_seq'::regclass);


--
-- Name: os_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_description ALTER COLUMN id SET DEFAULT nextval('os_description_id_seq'::regclass);


--
-- Name: os_log id_log; Type: DEFAULT; Schema: public; Owner: rami
--

ALTER TABLE ONLY os_log ALTER COLUMN id_log SET DEFAULT nextval('os_log_id_log_seq'::regclass);


--
-- Name: os_loginlog id_loginlog; Type: DEFAULT; Schema: public; Owner: rami
--

ALTER TABLE ONLY os_loginlog ALTER COLUMN id_loginlog SET DEFAULT nextval('os_loginlog_id_loginlog_seq'::regclass);


--
-- Name: os_r_personnel id_pers; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_r_personnel ALTER COLUMN id_pers SET DEFAULT nextval('os_r_personnel_id_pers_seq'::regclass);


--
-- Name: os_typologie id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_typologie ALTER COLUMN id SET DEFAULT nextval('os_typologie_id_seq'::regclass);


--
-- Data for Name: funben2s; Type: TABLE DATA; Schema: public; Owner: rami
--

COPY funben2s (id, fbdnai, fbrnai, fbncon, fbnins, fbfic) FROM stdin;
\.
COPY funben2s (id, fbdnai, fbrnai, fbncon, fbnins, fbfic) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: os_benalmfic; Type: TABLE DATA; Schema: public; Owner: rami
--

COPY os_benalmfic (cprint, cptypp, cpncon, cpddef, id, cpdrad, cpdsai, cphmaj, cpimaj, cpnmut, cpncol) FROM stdin;
\.
COPY os_benalmfic (cprint, cptypp, cpncon, cpddef, id, cpdrad, cpdsai, cphmaj, cpimaj, cpnmut, cpncol) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: os_champ_modifiable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY os_champ_modifiable (id, id_desc, field, type_field) FROM stdin;
\.
COPY os_champ_modifiable (id, id_desc, field, type_field) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: os_condition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY os_condition (id, id_desc, field, operateur, type_field) FROM stdin;
\.
COPY os_condition (id, id_desc, field, operateur, type_field) FROM '$$PATH$$/2993.dat';

--
-- Data for Name: os_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY os_description (id, libelle, sql, id_typologie, colone_conditionupdate, email) FROM stdin;
\.
COPY os_description (id, libelle, sql, id_typologie, colone_conditionupdate, email) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: os_log; Type: TABLE DATA; Schema: public; Owner: rami
--

COPY os_log (id_log, date_log, requete, user_log, avant_update) FROM stdin;
\.
COPY os_log (id_log, date_log, requete, user_log, avant_update) FROM '$$PATH$$/2997.dat';

--
-- Data for Name: os_loginlog; Type: TABLE DATA; Schema: public; Owner: rami
--

COPY os_loginlog (id_loginlog, action, source, adresse_ip, emplacement, date_heure, nom_user, adresse_ip_public) FROM stdin;
\.
COPY os_loginlog (id_loginlog, action, source, adresse_ip, emplacement, date_heure, nom_user, adresse_ip_public) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: os_r_personnel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY os_r_personnel (id_pers, identifiant, mdp, nom, prenom, email) FROM stdin;
\.
COPY os_r_personnel (id_pers, identifiant, mdp, nom, prenom, email) FROM '$$PATH$$/3001.dat';

--
-- Data for Name: os_typologie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY os_typologie (id, libelle, icone) FROM stdin;
\.
COPY os_typologie (id, libelle, icone) FROM '$$PATH$$/3003.dat';

--
-- Name: funben2s_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rami
--

SELECT pg_catalog.setval('funben2s_id_seq', 1, false);


--
-- Name: os_benalmfic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rami
--

SELECT pg_catalog.setval('os_benalmfic_id_seq', 1, false);


--
-- Name: os_champ_modifiable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('os_champ_modifiable_id_seq', 1, true);


--
-- Name: os_condition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('os_condition_id_seq', 7, true);


--
-- Name: os_description_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('os_description_id_seq', 6, true);


--
-- Name: os_log_id_log_seq; Type: SEQUENCE SET; Schema: public; Owner: rami
--

SELECT pg_catalog.setval('os_log_id_log_seq', 60, true);


--
-- Name: os_loginlog_id_loginlog_seq; Type: SEQUENCE SET; Schema: public; Owner: rami
--

SELECT pg_catalog.setval('os_loginlog_id_loginlog_seq', 46, true);


--
-- Name: os_r_personnel_id_pers_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('os_r_personnel_id_pers_seq', 12, true);


--
-- Name: os_typologie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('os_typologie_id_seq', 8, true);


--
-- Name: funben2s Cle primaire funben2s; Type: CONSTRAINT; Schema: public; Owner: rami
--

ALTER TABLE ONLY funben2s
    ADD CONSTRAINT "Cle primaire funben2s" PRIMARY KEY (id);


--
-- Name: os_loginlog Pk_loginlog; Type: CONSTRAINT; Schema: public; Owner: rami
--

ALTER TABLE ONLY os_loginlog
    ADD CONSTRAINT "Pk_loginlog" PRIMARY KEY (id_loginlog);


--
-- Name: os_benalmfic os_benalmfic_pkey; Type: CONSTRAINT; Schema: public; Owner: rami
--

ALTER TABLE ONLY os_benalmfic
    ADD CONSTRAINT os_benalmfic_pkey PRIMARY KEY (id);


--
-- Name: os_champ_modifiable os_champ_modifiable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_champ_modifiable
    ADD CONSTRAINT os_champ_modifiable_pkey PRIMARY KEY (id);


--
-- Name: os_condition os_condition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_condition
    ADD CONSTRAINT os_condition_pkey PRIMARY KEY (id);


--
-- Name: os_description os_description_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_description
    ADD CONSTRAINT os_description_pkey PRIMARY KEY (id);


--
-- Name: os_r_personnel os_r_personnel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_r_personnel
    ADD CONSTRAINT os_r_personnel_pkey PRIMARY KEY (id_pers);


--
-- Name: os_typologie os_typologie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY os_typologie
    ADD CONSTRAINT os_typologie_pkey PRIMARY KEY (id);


--
-- Name: os_log pk_log; Type: CONSTRAINT; Schema: public; Owner: rami
--

ALTER TABLE ONLY os_log
    ADD CONSTRAINT pk_log PRIMARY KEY (id_log);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

