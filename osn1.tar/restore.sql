--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.17
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.mi DROP CONSTRAINT mi_pkey;
ALTER TABLE public.mi ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.mi_id_seq;
DROP TABLE public.mi;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: mi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mi (
    id integer NOT NULL,
    numero character varying,
    mac character varying,
    ip character varying,
    date date,
    product character varying
);


ALTER TABLE mi OWNER TO postgres;

--
-- Name: mi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mi_id_seq OWNER TO postgres;

--
-- Name: mi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mi_id_seq OWNED BY mi.id;


--
-- Name: mi id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mi ALTER COLUMN id SET DEFAULT nextval('mi_id_seq'::regclass);


--
-- Data for Name: mi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mi (id, numero, mac, ip, date, product) FROM stdin;
\.
COPY mi (id, numero, mac, ip, date, product) FROM '$$PATH$$/2913.dat';

--
-- Name: mi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mi_id_seq', 691, true);


--
-- Name: mi mi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mi
    ADD CONSTRAINT mi_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

